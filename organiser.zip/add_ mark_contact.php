<div id="add_mark" style="
width:100%;
border-bottom: 1px solid brown;
background-color:#CCCCEE;
text-align:center
">
Add a marketing contact!
</div>