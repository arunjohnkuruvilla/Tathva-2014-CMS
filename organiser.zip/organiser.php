<?php 
include ("initdb.php");
_exit("Error: missing organiser page"); ?>