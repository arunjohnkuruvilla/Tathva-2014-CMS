<?php
$msg="";
$host = 'localhost';
$db_name = 'nitcfest_tathva12';
$db_user = 'nitcfest_tat12';
$db_password = '</tathva>';
$start_page = 'login.php';
$nu_page = 'home.php';
$pr_page = 'proofreader.php';
$mk_page = 'kash.php';
$mn_page = 'manager.php';
$ad_page = 'terminal.php';
$u_ad="admin";
$p_ad="ideate13";
$ml_page = 'mail.php';
$u_ml="mailer";
$p_ml="tmailer";
$cl_page = 'cl.php';
$u_cl="colleges";
$p_cl="clist";
$pl_page = 'pl.php';
$u_pl="publicity";
$p_pl="tpub";
?>
