<div id="footer">
	<div id="help">Help</div>
	<div id="footer-main">
		Tathva 2013 - Content Management System 2.0
	</div>
</div>