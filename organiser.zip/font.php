  <style>
    @font-face {
  font-family:"Cafe_Tathva";
  src:url('CafeNeroM54.ttf');
  }
  .goodfont
   {
    font-family:"Cafe_Tathva";
   }
  @font-face {
    font-family:"tathva";
    src:url('tathva.ttf');
    }
    .tatfont
     {
      font-family:"tathva";
    }
  </style>